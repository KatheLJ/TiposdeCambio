/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$(document).ready(function () {
    consultarTipoCambio();

});

function consultarTipoCambio() {
    
    // Se crean las variables requeridas
    result = document.getElementById("Resultado");
    montoPedido = document.getElementById("txtMonto").value;
    var de=document.getElementById("demoneda").value;
    var a=document.getElementById("amoneda").value;
    
    pMonto = document.getElementById("monto");
    
    
    $.ajax({
        url: '../backend/controller/tipoCambio.php',
        type: 'POST',
        data: {
            action: "consultarTipoCambio"
        },
        error: function () { //si existe un error en la respuesta del ajax
            swal("Error", "Se presento un error al enviar la informacion", "error");
        },
        success: function (data) { //si todo esta correcto en la respuesta del ajax, la respuesta queda en el data
            var json  = JSON.parse(data.trim());
            //alert(json.compra);
            //alert(json.venta);
         
            //De colónes a dólares
            if(de=='1'&&a=='2'){
                document.getElementById("monto").value = pMonto.innerHTML = montoPedido / json.venta;
            }
            
            //de dólares a colones
            else if(de=='2'&&a=='1'){
                document.getElementById("monto").value = pMonto.innerHTML = montoPedido * json.compra;
            }
            
            //de colones a euros
            else if(de=='1'&&a=='3'){
                document.getElementById("monto").value = pMonto.innerHTML = montoPedido / 730;
            }
            
            //de euros a colones
            else if(de=='3'&&a=='1'){
                document.getElementById("monto").value = pMonto.innerHTML = montoPedido * 730;
            }
            
            //de dólares  euros
            else if(de=='2'&&a=='3'){
                document.getElementById("monto").value = pMonto.innerHTML = montoPedido / 1.17750;

            }
            
            //de euros a dólares
            else if(de=='3'&&a=='2'){
                document.getElementById("monto").value = pMonto.innerHTML = montoPedido * 1.17750;
            }
            
        }
    });
}




/*function convertir(){
    
    var valor =parseInt(document.getElementById("txtMonto").value);
    //document.getElementById("valor").innerHTML= <b>"+valor+"</b>;
    var de=document.getElementById("demoneda").value;
    var a=document.getElementById("amoneda").value;
    //var compra= 618;
    //var venta = 624;
    Resultado = 0;
    
    //de Colones a dólar
    if(de===1&&a===2){
        Resultado=valor/compra;
    }
    //de dólares a colones
    else if(de===2&&a===1){
        Resultado=valor*venta;
    }
    document.getElementById("Resultado").innerHTML="<h1>"+Resultado+"</h1>";
    
}*/
